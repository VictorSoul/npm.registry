module.exports = {
  package: {
    name: 'no-license',
    license: null,
  },
  __requires: ['./default']
};
