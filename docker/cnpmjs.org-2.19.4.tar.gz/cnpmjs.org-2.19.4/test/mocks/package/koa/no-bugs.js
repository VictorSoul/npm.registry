module.exports = {
  package: {
    name: 'no-bugs',
    bugs: {
      url: null,
    },
  },
  __requires: ['./default']
};
