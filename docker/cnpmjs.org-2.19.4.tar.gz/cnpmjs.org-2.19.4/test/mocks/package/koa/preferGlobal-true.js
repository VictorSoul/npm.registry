module.exports = {
  package: {
    preferGlobal: true,
  },
  __requires: ['./default']
};
