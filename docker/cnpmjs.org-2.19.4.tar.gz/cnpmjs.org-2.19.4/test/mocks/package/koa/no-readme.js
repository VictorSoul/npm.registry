module.exports = {
  package: {
    readme: '',
  },
  __requires: ['./default']
};
