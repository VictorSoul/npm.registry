module.exports = {
  package: {
    name: 'koa',
    repository: null,
  },
  __requires: ['./default']
};
