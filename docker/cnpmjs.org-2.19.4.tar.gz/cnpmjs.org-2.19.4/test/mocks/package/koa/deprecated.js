module.exports = {
  package: {
    deprecated: 'This package has been deprecated.',
  },
  __requires: ['./default']
};
