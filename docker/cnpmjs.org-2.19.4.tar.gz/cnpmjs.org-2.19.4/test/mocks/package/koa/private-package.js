module.exports = {
  package: {
    name: '@fengmk2/fs',
    _publish_on_cnpm: true,
  },
  __requires: ['./default']
};
