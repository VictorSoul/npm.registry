# test < >

```html
<body>hi</body>
```

```js
var a = 1 > 2 ? 'a' : 'b';
```
