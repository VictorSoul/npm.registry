Configuration Wizard: <!--- This is what the user will see during the configuration ->
